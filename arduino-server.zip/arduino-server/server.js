const express = require('express');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const sqlite = require('sqlite');
const sqlite3 = require('sqlite3');
const path = require('path');

const app = express();
const port = 3000;

const portName = 'COM4'; 
const baudRate = 9600;

let db;
let latestData = {
    humidity: 0,
    temperature: 0,
    timestamp: "N/A"
};

async function setupDatabase() {
    db = await sqlite.open({
        filename: './sensor_history.db',
        driver: sqlite3.Database
    });

    await db.run(`
        CREATE TABLE IF NOT EXISTS readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            humidity REAL,
            temperature REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);
    console.log("Database initialized.");
}

try {
    const serial = new SerialPort({ path: portName, baudRate: baudRate });
    const parser = serial.pipe(new ReadlineParser({ delimiter: '\n' }));

    serial.on('open', () => console.log(`Connected to Arduino on ${portName}`));

    parser.on('data', async (data) => {
        const parts = data.trim().split(',');
        if (parts.length === 2) {
            const h = parseFloat(parts[0]);
            const t = parseFloat(parts[1]);

            latestData = {
                humidity: h,
                temperature: t,
                timestamp: new Date().toLocaleTimeString()
            };

            if (db) {
                await db.run(
                    'INSERT INTO readings (humidity, temperature) VALUES (?, ?)',
                    [h, t]
                );
            }
        }
    });
} catch (err) {
    console.error("Serial Port Error: ", err.message);
}

app.use(express.static('public'));

app.get('/api/data', (req, res) => res.json(latestData));

app.get('/api/history', async (req, res) => {
    if (!db) return res.status(500).send("DB not ready");
    try {
        const rows = await db.all(`
            SELECT 
                datetime((strftime('%s', timestamp) / 300) * 300, 'unixepoch', 'localtime') AS interval_time,
                AVG(temperature) as avg_temp,
                AVG(humidity) as avg_humid
            FROM readings
            WHERE timestamp < datetime('now', '-5 minutes')
            GROUP BY interval_time
            ORDER BY interval_time DESC
            LIMIT 20
        `);
        res.json(rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

setupDatabase().then(() => {
    app.listen(port, () => console.log(`Server running at http://localhost:${port}`));
});